# Crease Performance — Netlify deployment

This is a static web app. No APK, Android Studio, build command, or server is required.

## Deploy from an Android phone
1. Open https://app.netlify.com/drop in Chrome and sign in or create a free Netlify account.
2. Extract this ZIP on your phone using Files/File Manager.
3. Upload/drag the extracted `crease_performance_netlify` folder (the folder containing `index.html`) onto the Netlify Drop page. If the browser's folder picker is unavailable, use Netlify's manual deploy flow and select the extracted folder.
4. Wait for deployment. Netlify will give you a public `*.netlify.app` URL.
5. Open that URL on your phone. In Chrome, use the three-dot menu → Add to Home screen (or Install app, if shown).

## Notes
- Keep `index.html`, `manifest.webmanifest`, `sw.js`, and both icon PNG files together in the published folder.
- Session and profile data are stored in that browser/device's local storage. They do not automatically sync between devices.
- To update the site, upload the updated folder again through Netlify.
